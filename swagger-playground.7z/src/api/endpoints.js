const base = '/api/v1.0';

export const ApiEndpoints = {
  swagger: {
    list: `${base}/swagger/files`,
    upload: `${base}/swagger/file/upload`,
  },
};
